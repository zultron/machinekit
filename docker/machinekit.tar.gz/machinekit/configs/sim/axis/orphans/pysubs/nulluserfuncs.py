# empty extension object to make inheritance work

class UserFuncs(object):

    pass
