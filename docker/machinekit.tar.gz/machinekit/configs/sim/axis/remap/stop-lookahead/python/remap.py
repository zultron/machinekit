import interpreter

def queuebuster(self, **words):
    yield interpreter.INTERP_EXECUTE_FINISH


