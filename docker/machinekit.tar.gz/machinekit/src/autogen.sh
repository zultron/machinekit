#!/bin/sh
autoreconf -fiI m4
