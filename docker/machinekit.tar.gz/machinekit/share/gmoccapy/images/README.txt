This is just a list showing the origin from the icons

the following icons are from moccagui projekt:
http://code.google.com/p/moccagui/
with the friendly permission from the owner 
info@jetsport.de

coolant_off.png
coolant_on.png   (modified by nieson@web.de)
editor.png
E-Stop.gif
estopred.png
forward.png
forward_on.png   (modified by nieson@web.de)
mist_off.png
mist_on.png      (modified by nieson@web.de)
pause.png
refall.png
refx.png
refy.png
refz.png
reverse.png
reverse_on.png  (modified by nieson@web.de)
runfrom.png
start.png
step.png
stop.gif
stop.png
stop_on.png
toolchange.png
tools.png
touchoffwz.png
touchoffx.png
touchoffy.png
touchoffz.png
touchoffx_value.png    (modified by nieson@web.de)
touchoffy_value.png    (modified by nieson@web.de)
touchoffz_value.png    (modified by nieson@web.de)
unhome.png

the following icons are created by nieson@web.de under free license
Logo.png
index_tool.png
tool_by_no.svg
user_tabs.png (modified two icon from openiconlibrary)
refa.png (modified from moccagui)
refb.png (modified from moccagui)
refc.png (modified from moccagui)
refu.png (modified from moccagui)
refv.png (modified from moccagui)
refw.png (modified from moccagui)

the following Icons are from linuxcnc
toolaxisp.png
toolaxisx.png
toolaxisy.png
toolaxisz.png
tool_blockdelete.gif
toolpath.png
applet-critical.png
clear.png
std_info.gif

and this icons are from openiconlibrary.sourceforge.net
clear.png
configure-2.png
dimensions.png
enter.png
exit.png
exit_application.png
keyboard.png
reload.png
save.png
saveas.png
toolpath.png
zoom-in.png
zoom-out.png
fullscreen_preview.png

and this one are from Dejan (probamo from linuxcnc forum)
machine_off.png
machine_on.png
manual_mode.png
mdi_mode.png
auto_mode.png


