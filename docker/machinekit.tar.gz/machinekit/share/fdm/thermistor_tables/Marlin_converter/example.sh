#!/bin/sh
./ConvertTable.py -i artifex_hb_marlin.txt -o artifex_hb.txt